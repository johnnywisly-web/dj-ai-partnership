# DJ AI Partnership LLC Recruitment Website

## Included
- Home page
- Latest Opportunities section
- Current AI Data Collection project
- About Us
- How It Works
- FAQ
- Apply buttons connected to the provided Google Form
- Responsive mobile/tablet/desktop design

Application form:
https://forms.gle/seTs2W87QmFvXMPX8

## Free hosting
GitHub Pages:
1. Create a public GitHub repository.
2. Upload index.html and style.css.
3. Go to Settings > Pages.
4. Select the main branch and save.

The website can also be deployed on Netlify or another static hosting provider.
